ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS read_at timestamptz;
