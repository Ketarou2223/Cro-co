ALTER TABLE profiles ADD COLUMN IF NOT EXISTS birth_date date;
